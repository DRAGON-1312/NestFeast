# autocomplete (services)
from __future__ import annotations

"""
Service cho tính năng Autocomplete địa chỉ / địa điểm.

Nhiệm vụ:
- Nhận query user đang gõ + optional tọa độ bias.
- Gọi providers.trackasia.autocomplete.autocomplete_v2.
- Chuẩn hóa về model AutocompleteSuggestion đơn giản cho API / FE.
"""

from dataclasses import dataclass, asdict
from typing import Any, Dict, List, Optional, Tuple
import asyncio
from app.providers.trackasia.autocomplete import (
    AutocompleteCandidate,
    autocomplete_v2,
)


# ===== Domain model cho tầng service (không phụ thuộc FastAPI / Pydantic) =====
@dataclass
class AutocompleteSuggestion:
    """Gợi ý autocomplete dùng để render dropdown 2 dòng trong FE."""

    place_id: str

    # Dòng chính (in đậm): tên địa điểm / số nhà + tên đường
    main_text: str

    # Dòng phụ (xám): quận/huyện, tỉnh/thành, country...
    secondary_text: str

    # Mô tả đầy đủ (có thể dùng cho tooltip / debug)
    description: str

    lat: Optional[float] = None
    lng: Optional[float] = None

    # Các field extra nếu cần mở rộng sau
    official_id: Optional[str] = None
    old_description: Optional[str] = None
    old_formatted_address: Optional[str] = None

    # raw để debug (KHÔNG trả ra API, chỉ dùng nội bộ nếu cần)
    raw: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        """Chuyển sang dict để API / Pydantic dễ dùng."""
        d = asdict(self)
        # raw chỉ để debug, thường không trả về client
        d.pop("raw", None)
        return d


# ===== Helper chuyển từ provider model sang service model =====
def _map_candidate(c: AutocompleteCandidate) -> AutocompleteSuggestion:
    return AutocompleteSuggestion(
        place_id=c.place_id,
        main_text=c.main_text or c.description or "",
        secondary_text=c.secondary_text or "",
        description=c.description or "",
        lat=c.lat,
        lng=c.lng,
        official_id=c.official_id,
        old_description=c.old_description,
        old_formatted_address=c.old_formatted_address,
        raw=c.raw,
    )


# ===== Public API cho các router / service khác dùng =====
async def suggest_places(
    query: str,
    *,
    center: Optional[Tuple[float, float]] = None,
    limit: int = 5,
    new_admin: bool = True,
    include_old_admin: bool = False,
) -> List[AutocompleteSuggestion]:
    """
    Gợi ý autocomplete cho input `query`.

    Parameters
    ----------
    query:
        Chuỗi user đang gõ trong ô input.
    center:
        (lat, lng) để bias kết quả quanh một điểm (ví dụ: origin hiện tại).
    limit:
        Số gợi ý tối đa.
    new_admin / include_old_admin:
        Điều khiển địa giới hành chính theo docs TrackAsia.

    Returns
    -------
    List[AutocompleteSuggestion]:
        Danh sách gợi ý đã chuẩn hóa; [] nếu có lỗi hoặc không có kết quả.
    """
    if not query or not query.strip():
        return []

    try:
        candidates = await autocomplete_v2(
            query=query.strip(),
            location=center,
            size=limit,
            new_admin=new_admin,
            include_old_admin=include_old_admin,
        )
    except Exception:
        # provider layer hầu như đã nuốt lỗi, nhưng để chắc chắn:
        return []

    return [_map_candidate(c) for c in candidates]


async def suggest_places_as_dict(
    query: str,
    *,
    center: Optional[Tuple[float, float]] = None,
    limit: int = 5,
    new_admin: bool = True,
    include_old_admin: bool = False,
) -> List[Dict[str, Any]]:
    """
    Giống suggest_places nhưng trả List[dict] – tiện dùng trực tiếp trong API router.
    """
    suggestions = await suggest_places(
        query=query,
        center=center,
        limit=limit,
        new_admin=new_admin,
        include_old_admin=include_old_admin,
    )
    return [s.to_dict() for s in suggestions]


def suggest_places_sync(
    query: str,
    *,
    center: Optional[Tuple[float, float]] = None,
    limit: int = 5,
    new_admin: bool = True,
    include_old_admin: bool = False,
) -> List[Dict[str, Any]]:
    """
    Wrapper sync – tiện gọi từ Streamlit.
    Trả List[dict] giống suggest_places_as_dict.
    - Nếu không có event loop: dùng asyncio.run
    - Nếu đang có event loop (ít gặp): chạy coroutine trong 1 thread riêng.
    """
    async def _coro():
        return await suggest_places_as_dict(
            query=query,
            center=center,
            limit=limit,
            new_admin=new_admin,
            include_old_admin=include_old_admin,
        )

    try:
        # Trường hợp bình thường (không có loop đang chạy) — phù hợp với Streamlit
        return asyncio.run(_coro())
    except RuntimeError:
        # Có loop đang chạy -> dùng thread phụ để tạo loop mới an toàn
        from threading import Thread
        from queue import Queue

        q: "Queue[List[Dict[str, Any]]]" = Queue()

        def runner():
            q.put(asyncio.run(_coro()))

        t = Thread(target=runner, daemon=True)
        t.start()
        t.join()
        return q.get()
        
        
# ====== Demo thủ công (chạy trực tiếp file này) ======
if __name__ == "__main__":
    import asyncio

    async def _demo():
        res = await suggest_places("Landmark 81", center=(10.7952, 106.7218))
        print("Got", len(res), "suggestion(s).")
        for i, s in enumerate(res, 1):
            print(
                f"{i}. {s.main_text} | {s.secondary_text} | "
                f"{s.lat},{s.lng} | place_id={s.place_id}"
            )

    asyncio.run(_demo())
